<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_pengeluaran');
        $this->load->model('Model_jurusan');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Pengeluaran';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['pengeluaran'] = $this->Model_pengeluaran->getAllPengeluaran($data['keyword']);
       
        $this->load->view('templates/header.php', $data);
        $this->load->view('pengeluaran/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['jurusan'] = $this->Model_jurusan->getAllJurusan();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required|numeric');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Pengeluaran';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengeluaran/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pengeluaran->Tambahpengeluaran();
            redirect('pengeluaran');
        }
        
    }

    public function ubah($id)
    {
        $data['pengeluaran'] = $this->Model_pengeluaran->getPengeluaranById($id);
        $data['jurusan'] = $this->Model_jurusan->getAllJurusan();
        $this->form_validation->set_rules('nis', 'Nis', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('angkatan', 'Angkatan', 'trim|required|numeric');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Pengeluaran';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pengeluaran/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pengeluaran->Ubahpengeluaran();
            $old_image = $data['pengeluaran']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('pengeluaran');
        }
        
    }

    public function detail($id)
    {
        $data['pengeluaran'] = $this->Model_pengeluaran->getPengeluaranById($id);
       
        $data['title'] = 'Detail Pengeluaran';
        $this->load->view('templates/header.php', $data);
        $this->load->view('pengeluaran/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['pengeluaran'] = $this->Model_pengeluaran->getPengeluaranById($id);
        $old_image = $data['pengeluaran']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_pengeluaran->hapuspengeluaran($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('pengeluaran');
    }
}