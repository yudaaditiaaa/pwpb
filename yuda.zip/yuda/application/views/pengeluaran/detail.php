<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $pengeluaran['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $pengeluaran['nis']; ?></h5>
            <p class="card-text"><?= $pengeluaran['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $pengeluaran['angkatan']; ?></li>
            <li class="list-group-item"><?= $pengeluaran['jurusan']; ?></li>
            <li class="list-group-item"><?= $pengeluaran['email']; ?></li>
            <li class="list-group-item"><?= $pengeluaran['hp']; ?></li>
            <li class="list-group-item"><?= $pengeluaran['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('pengeluaran'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

