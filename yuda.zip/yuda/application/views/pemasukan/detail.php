<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $pemasukan['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $pemasukan['nis']; ?></h5>
            <p class="card-text"><?= $pemasukan['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $pemasukan['angkatan']; ?></li>
            <li class="list-group-item"><?= $pemasukan['jurusan']; ?></li>
            <li class="list-group-item"><?= $pemasukan['email']; ?></li>
            <li class="list-group-item"><?= $pemasukan['hp']; ?></li>
            <li class="list-group-item"><?= $pemasukan['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('pemasukan'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

